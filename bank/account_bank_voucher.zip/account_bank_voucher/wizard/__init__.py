# -*- encoding: utf-8 -*-
import bank_statement_populate

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
